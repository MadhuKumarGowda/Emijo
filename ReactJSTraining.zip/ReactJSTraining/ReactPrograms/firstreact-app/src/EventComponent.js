import React from 'react';
import ReactDOM from 'react-dom';   

export class EventComponent extends React.Component{
   
    constructor(){
        super();
        this.num = 1;
        this.state = {
        data : []
        };
        this.colorCode = "";
        
        this.increment =  this.incrementtheNumber.bind(this);
        this.reset =  this.reset.bind(this);
        this.findDOMNode = this.applyColor.bind(this);
        this.update = this.getColor.bind(this);
        this.textInput = React.createRef();
        this.getFocus = this.getFocus.bind(this);        
    }

    incrementtheNumber(){
        var myarray = this.state.data.slice();
        myarray.push(this.num);
        this.setState({data:myarray});
        this.num++;        
    }

    reset(){
        this.setState({data:[]});
        this.num = 1;
    }

    getColor(){
        this.colorCode = this.refs.colorCode.value;
    }

    applyColor(){        
        var c = document.getElementById('container');
        ReactDOM.findDOMNode(c).style.color = this.colorCode;
    }

    getFocus(){
        this.textInput.current.focus();
    }
    
    render(){
        return(
            <div>
                <button onClick={this.increment}> increment Number </button>
                <button onClick={this.reset}> Reset Number </button>
                <h1> {this.num} </h1>
                <h1> {this.state.data.length} </h1>
                <br/>
                <input type="text" ref="colorCode" onChange={this.update} />
                <div id="container"> Hello Madhu </div>
                <button onClick={this.findDOMNode}> Get Color </button> <br/>
                <input type="text" ref={this.textInput} />

                 <button onClick={this.getFocus}> Focus the input </button>
            </div>
        );
    }
}