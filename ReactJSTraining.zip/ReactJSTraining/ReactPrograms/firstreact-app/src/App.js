// component file

import React from 'react';
import {Component1,SumofNumbers} from './Component1';
import {EventComponent} from './EventComponent'; 
import {ParentComponent} from './ParentComponent'; 


var arrNumbers = [1,2,3,4,5,6,7];

 export default class App extends React.Component {
   constructor(){
     super();
     this.name = "Madhu" ;
     this.location = " Lives in Mysuru";     
   }
    render() {
      return( 
        <div>  
          <h4> {this.name} , {this.location} </h4>      
          <h4> {this.props.qualifications == null ? "Default " : this.props.qualifications} Studied at {this.props.college} </h4>
          <h3> {this.props.address.street} - {this.props.address.City} </h3>
          <Calu/>
        <Component1/> 
        <SumofNumbers a = {this.props.numbers.A} b={this.props.numbers.B}/>
        <PassNumbers n1 = {this.props.n1} n2 = {this.props.n2}/>
        <EventComponent/>
        <ParentComponent numbers={arrNumbers} playersObj={this.props.playerObj}/>
        <br/>
       
        </div>
      );
    }
 } 

 class PassNumbers extends React.Component {
   render(){
     return(
       <h2> {parseInt(this.props.n1) + parseInt(this.props.n2)} </h2>
     );
   }
 }

 export class Country extends React.Component{
   render() {

    var style = {
      fontSize : 30,
      color : 'red',
      listStyle : 'none'
      
    }
     return( 
       <div>
        <h1> Countries List </h1>     
        <ul style={style}>
          <li> India </li>
          <li> America </li>
          <li> China </li>
          <li> Russia </li>
          <li> Brazil </li>
       </ul>
       <Company/>
       </div>
     );
   }
 }

 
 class Calu extends React.Component {
   render() {
    var i = 8 ;
    if( i % 2 === 0){
      return (
        <h4> Even Number </h4>
      )
    }else{
      return (
        <h4> Odd Number </h4>
      )
    }
   }
 }

 class Company extends React.Component {
   render() {
    var style = {
      fontSize : 25,
      color : 'Blue',
      listStyle : 'none',
      padding:0
    }
     return (
      <div>
      <h1> Companies List </h1>     
      <ul style={style}>
        <li> LnT </li>
        <li> Infosys </li>
        <li> IBM </li>
        <li> Thales </li>
        <li> Covidien </li>
     </ul>
     </div>
     )
   }
 }
 
