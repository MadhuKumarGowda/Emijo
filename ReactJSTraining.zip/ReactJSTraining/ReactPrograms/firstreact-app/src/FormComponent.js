import React from 'react';

export class FormComponent extends React.Component {
    constructor(props)
      {
            super(props);
            this.state={value:''};
            this.handleChange=this.handleChange.bind(this);
            this.handleSubmit=this.handleSubmit.bind(this);
      }

      handleChange(event)
      {
            console.log('handleChange');
            this.setState({value:event.target.value});
      }

      handleSubmit(event)
      {
            if (this.state.value==='')
            {
            alert("Can't be empty");
            event.preventDefault();
            }
            else{
                  alert('fine, will call REST API');
            }
      }
      render() {
        return (
            <form onSubmit={this.handleSubmit}>
            <label>
              Name:
              <input type="text" value={this.state.value} onChange={this.handleChange} />
            </label>
            <input type="submit" value="Submit" />
          </form>
        );
      }
}
