import React from 'react';

class Component1 extends React.Component {
    render() {
        return( 
          <div>        
            <h1> Hello from Component1 </h1>
          </div>
        );
      }
   } 

 class SumofNumbers extends React.Component {
   render () {
     return(
       <div>
         <h1> Sum of {this.props.a} and {this.props.b} is {this.props.a + this.props.b} </h1>
         </div>
     )
   }
 } 

//export default Component1;
export {Component1,SumofNumbers};
