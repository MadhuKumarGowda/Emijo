import React from 'react';
import {ChildComponent} from './ChildComponent';

export class ParentComponent extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={myData:'Initial Msg '};
        this.change=this.updateState.bind(this);
    }

    updateState()
    {
	this.setState({myData:'Changed from Child Component'});
    }

    render()
    {
        return(
            <div>
                 <ChildComponent myDataProp={this.state.myData} number = {this.props.numbers} 
                 playersObj={this.props.playersObj}
                   updateProp={this.change}/>
            </div>
        );
    }
}
