import React from 'react';
import ReactDOM from 'react-dom';
import App,{Country} from './App';
import {FormComponent} from './FormComponent';

var Address = {
    street : '21',
    City : 'Mysuru'
}

var numbers = {
    A: 15,
    B: 25
}

var palyerDetails = [
    {name: 'Sachin' , Country : 'India'},
    {name: 'ABD' , Country : 'SA'},
    {name: 'Hales' , Country : 'England'}
]

ReactDOM.render(
    
     <App qualifications="Master of Computer Applications" college="PESSE" address = {Address}
     numbers = {numbers} n1='10' n2='10' playerObj = {palyerDetails}/>,
        document.getElementById('root')
);

ReactDOM.render(
    <FormComponent/>,
    document.getElementById('formControl')
)

ReactDOM.render(
     <Country/>,
     document.getElementById('list')
)

// ReactDOM.render(
//     <Calu/>,
//     document.getElementById('expression')
// )
