import React from 'react';
export class ChildComponent extends React.Component
{
    constructor(props){
        super(props);
        this.number = props.number;
        this.listItems = 
        this.number.map((index) =>
        <li key={index.toString()}> {index} </li>
        );

        this.players = props.playersObj;
        
        this.playerList = 
        this.players.map((idx) =>
        <li key={idx.name.toString()}> {idx.name}  Play for   {idx.Country} </li>
        );
    }
    render()
    {
        return(

            <div>
                <button onClick={this.props.updateProp}>Click</button>
                <h3> In child component: value is: {this.props.myDataProp}</h3>
                <div> <table class="table table-striped"> {this.listItems} </table> </div>
                <div> {this.playerList} </div>
            </div>
        );
    }
}