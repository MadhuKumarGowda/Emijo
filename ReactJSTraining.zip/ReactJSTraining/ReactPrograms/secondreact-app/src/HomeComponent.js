import React , {Component} from 'react';
import {UserComponent} from './UserComponents';

export class HomeComponent extends Component {
    render() {
        return(
            <div class="container">
                <div class="row">
                 Hello from Home Page </div>
                 <br/>
                 <div class="row">
                 <UserComponent/>
                 </div>
            </div>
        )
    }
}