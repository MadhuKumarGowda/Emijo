import React from 'react';
import ReactDOM from 'react-dom';

import RouteApp from './RouteApp';


ReactDOM.render(<RouteApp />, document.getElementById('root'));