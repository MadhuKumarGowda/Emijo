import React , {Component} from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import {HomeComponent} from './HomeComponent';
import {LoginComponent} from './LoginComponent';
import {UserComponent} from './UserComponents';

class RouteApp extends Component {
    render() {
        var align = {
            textAlign : 'center'
        }
       return (
          <Router>
             <div>
                <h2 style={align}>Welcome to React Router Tutorial</h2>
                <nav class="navbar navbar-expand-sm navbar-light bg-light">
                    <Link class="navbar-brand" to={'/'}>Home</Link>
                    <Link class="navbar-brand" to={'/Login'}>Login</Link>
                    <Link class="navbar-brand" to={'/User'}>User Details</Link>
                </nav>
                <hr/>
                
                <Switch>
                   <Route exact path='/' component={HomeComponent} />
                   <Route exact path='/Login' component={LoginComponent} />
                   <Route exact path='/User' component={UserComponent} />
                </Switch>
             </div>
          </Router>
       );
    }
 }
 export default RouteApp;