import React , {Component} from 'react';

export class UserComponent extends Component {
    constructor(props){
        super(props);
        this.state = {users : []};
    }

    componentDidMount(){
        console.log("Component did mount");
        fetch('https://jsonplaceholder.typicode.com/users')
        .then(result=> {
            return result.json();
        }).then(data=>{
            this.setState({users : data});
        })
    }
   
    render() {
        var textAlign = {
            textAlign : 'center'
        }
        return(
            <div class="container">
                <div class="row">
                 User Details </div>
                 <div class="col-md-12">
                    <table class="table table-striped table-bordered table-hover" id="userTable">
                    <thead>
                        <tr>
                            <th> Emp ID </th>
                            <th> Name </th>
                            <th> Email </th>
                            <th> phone </th>
                            <th> Company </th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.users.map((user)=>{
                            return  <tr key={user.id.toString()}>
                                       <td style={textAlign}>{user.id}</td>
                                       <td>{user.name}</td>
                                       <td> {user.email}</td>
                                       <td> {user.phone}</td>
                                       <td> {user.company.name}</td>
                                    </tr>
                        }) }
                    </tbody>
                    </table>
                 </div>
            </div>
        )
    }
}