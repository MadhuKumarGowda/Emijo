import React , {Component} from 'react';

export class LoginComponent extends Component{
    render() {
        return(
            <div class="container">
            <div class="row">
                <div class="form-group col-md-12">
                    <label> Enter User Name </label>
                    <input class="input-group" refs={this.username} /> 
                </div>
                <div class="form-group col-md-12">
                    <label> Enter Password </label>
                    <input type="password" class="input-group" refs={this.password} /> 
                </div>
                <div class="form-group col-md-12">                    
                    <button class="btn btn-primary"> Login </button>
                </div>
            </div>
            </div>
        )
    }
}