import "Timer.jsx";

interface swimable {
    abstract function swim():void;   
}

interface comparison{
    abstract function comapre(obj1:Object, obj2:Object):void;
}

// class Items implements comparison{
//     LName: string;
//     Lprice: number;
//     Lmodel: string;
//     function constructor(){

//     }
//     override function comparison(obj1:Object, obj2:Object): void {
//         if(obj1.price > obj2.price){
//             log "obj1 is more price";
//         }else{
//             log "obj2 is more price";
//         }
//     }
// }

class Fish implements swimable {
    override function swim() : void {
        log "A fish is swiming";
    }
}


class _Main {
    static function main(args:string[]):void{
        var fish = new Fish();
        fish.swim();
    }
}