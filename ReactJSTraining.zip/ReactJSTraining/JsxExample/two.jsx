import "Employee.jsx";
class _Main {
     static function main(args:string[]):void {
        var e1 = new Employee("Madhu", 12000);
        log(e1.eBonus + " -- " + e1.etax);
        log(e1.eName + " net salry is :" + e1.calcNetSalary());
        var e2 = new Employee(e1);
        log(e2.eBonus + " -- " + e2.etax);
        log(e2.eName + " net salry is :" + e2.calcNetSalary());
    }
}