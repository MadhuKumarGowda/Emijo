class Employee {
    var eName : string;
    var eSalary :number;
    var eBonus :number;
    var etax :number; 


    function constructor(eName:string,eSalary:number){
        this.eName = eName;
        this.eSalary = eSalary; 
        this.eBonus =  (eSalary * 5 ) /100;
        this.etax = (eSalary * 10) / 100; 
    }

    function constructor(e1:Employee){
        log "copy constructor is called";
        this.eName = e1.eName;
        this.eSalary = e1.eSalary;
        this.eBonus =  (e1.eSalary * 5 ) /100;
        this.etax = (e1.eSalary * 10) / 100; 
    }

    function calcNetSalary():number{        
        return  (this.eSalary + this.eBonus) - this.etax  ;
        
    }
}