class simple{
    var n = 123 ;

    function constructor() {
       
    }

    function f1() : void{
        log "function f1 is invoked";
        log (this.n);
         assert this.n != 0;
    }

    function exceptionCatch(A:number, B:number) : void {
        var result : number;
        try {
            result = A / B ;
            log result;
        } catch (e:TypeError) {
            log " Error occured coz :" ;
        }
        finally{
            log "Operation completed at finally block";
        }
    }
}


class _Main {
    static function main(args: string[]) : void {
        var s1 = new simple();
        s1.f1();
        s1.exceptionCatch(10,3);
        s1.exceptionCatch(10,0);
    }
}