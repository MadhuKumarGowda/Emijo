class product
{
    var name = '';
    var price = 0;

    function constructor(){

    }   

    function constructor(name:string, price:number){
        this.name = name;
        this.price = price;
    }
}

class _Main {
    static function main(args: string[]):void {
        var p1 = new product("samsung s9" , 50000);
        log(p1.name + " " + p1.price);
         var p2 = new product("samsung s9+" , 54000);
        log(p2.name + " " + p2.price);
    }
}




