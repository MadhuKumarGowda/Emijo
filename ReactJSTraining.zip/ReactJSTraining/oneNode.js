function one(){
    var a = 2;
    two();

    function two(){
        var b=3;
        three();    

            function three(){
                var c= 4;
                console.log(a + b + c);
        }
    }
}

// ------- Variable scope  
let name = "Madhu Kumar ";

function displayName(){
    console.log(name);
    if(true){
        let country = "India";
        console.log(country + name);
    }
    console.log(name);

}

// ---------- Pass by value function
function showmsg(from,text){
    from = "Mr." + from;
    console.log(text + from);
}

var from = "Madhu";
showmsg(from,'Welcome');
console.log(from);

one();
displayName();

//---------------- recurrsive function
function pow(x,n){
    if(n==1){        
        return x;
    }else{        
        return x * pow(x,n-1);
    }
}

console.log(pow(2,5));

// ---------- closure function 
var add = function(){
    console.log("Outer function")
    var counter = 0;
    return function(){
        return counter++
    }
}()

for(var i=0;i<=10;i++){
    console.log(add());    
}
